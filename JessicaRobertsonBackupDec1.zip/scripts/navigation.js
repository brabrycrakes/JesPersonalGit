$(function(){
	$('header .navbar li a').click(function () {	
		if ($(window).width() <= 767){	
			$('header .navbar button').click();
		}
	});

});