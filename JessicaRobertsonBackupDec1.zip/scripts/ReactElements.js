      var MemoryGameCard = React.createClass({
        render: function () {
          return (
						<div className="card">
							<div className="card-inner">
								<div className="logo"></div>
								<div className="card-content">
									<i className="fa fa-2x"></i>
								</div>		
							</div>						
						</div>					
					);
        }
      });
			
      var MemoryGameBoard = React.createClass({
        render: function () {
          return (
						<div className='card-box'>
							<MemoryGameCard /><MemoryGameCard /><MemoryGameCard /><MemoryGameCard />
							<MemoryGameCard /><MemoryGameCard /><MemoryGameCard /><MemoryGameCard />
							<MemoryGameCard /><MemoryGameCard /><MemoryGameCard /><MemoryGameCard />
							<div className='card-align'>
								<p>Moves: <span class='numMoves'></span></p>
								<button type="button" className='btn btn-default resetCards'>Reset</button>		
							</div>
						</div>
					);
        }
      });			
					 
      ReactDOM.render(
        <MemoryGameBoard />,
        document.getElementById('memoryGameBoard')
      );